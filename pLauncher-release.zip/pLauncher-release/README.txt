start World of Tanks
start executable
??
profit!

Have fun!

Executable is packed with vmprotect and injects a packed dll into world of tanks. This could lead to a false positive anti virus detection.
This executable is not a virus.